GAMIT/GLOBK/GLORG Final General Portable Robust Edition

This version is generated from the strongest previous GamitG_v2/bbbb line, but removes user/project/site/year/path hardcoded prompts.

Key behavior:
- Detects a likely RINEX folder from current directory, ./rinex, ~/rinex, ~/data, or environment variable AUTOM_GAMIT_RINEX_DIR.
- Infers year and first DOY from RINEX2/RINEX3 filenames where possible.
- Infers a generic 4-character experiment code from the source folder name, or uses AUTOM_GAMIT_EXPT.
- Requires the user to provide IGS/reference stations, or set AUTOM_GAMIT_IGS_SITES.
- Uses FALLBACK_IGS_SITES only if the user explicitly sets it; otherwise it reuses the primary reference list.
- Uses AUTOM_GAMIT_LOCAL_SITES in GLOBK only if local stations cannot be detected from sites.defaults.
- Supports JSON config via --config FILE and template creation via --write-template-config.
- Recommended orbit mode remains online pre-download of products/RINEX, then sh_gamit -orbit igsf -noftp -pres ELEV.

Typical install:
  bash install_general_portable_robust.sh

Verify:
  PYTHONDONTWRITEBYTECODE=1 python3 ~/GamiT_GlobK_Glorg_FINAL.py --verify

Run:
  PYTHONDONTWRITEBYTECODE=1 python3 ~/GamiT_GlobK_Glorg_FINAL.py

Optional environment variables:
  export AUTOM_GAMIT_RINEX_DIR=/path/to/rinex
  export AUTOM_GAMIT_EXPT=abcd
  export AUTOM_GAMIT_PROJECT=abcd2026
  export AUTOM_GAMIT_IGS_SITES="abcd efgh ijkl mnop"
  export FALLBACK_IGS_SITES="abcd efgh ijkl mnop qrst uvwx"
  export AUTOM_GAMIT_LOCAL_SITES="loc1 loc2 loc3"
  export AUTOM_GAMIT_AUTO_STAGE=1
