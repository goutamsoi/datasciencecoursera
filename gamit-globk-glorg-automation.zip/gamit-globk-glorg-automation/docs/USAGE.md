# Usage Guide

## 1. Run the launcher

```bash
python3 GamiT_GlobK_Glorg_FINAL.py
```

## 2. Menu choices

Choose:

```text
1. Run GAMIT only
2. Run GLOBK/GLORG only
3. Run full GAMIT first, then GLOBK/GLORG dashboard
```

For an existing successful GAMIT run, use option `2`.

## 3. GLOBK/GLORG-only workflow

The dashboard will:

1. scan available h-file days,
2. detect year, DOY range, experiment code, and network extension,
3. run tool/environment checks,
4. regenerate or check command files,
5. detect local stations,
6. select APR/EQ files,
7. repair local APR station entries when needed,
8. detect stabilization sites,
9. patch `globk.cmd` and `glorg.cmd`,
10. run normal `sh_glred` with `H G T` or `G T`,
11. optionally run combined survey with `COMB + -ncomb`,
12. extract final coordinates and output reports.

## 4. Recommended check after a run

```bash
ls -lh /path/to/project/gsoln/*.org
ls -lh /path/to/project/gsoln/final_outputs/
ls -lh /path/to/project/globk_glorg_logs/
```

## 5. Important warning

Do not manually run `glorg` on the `.org` file. Let `sh_glred` and the dashboard workflow handle the normal GLOBK/GLORG process.
