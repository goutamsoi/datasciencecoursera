#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="$HOME/GamiT_GlobK_Glorg_FINAL.py"
if [ -f "$TARGET" ]; then
  cp -f "$TARGET" "$TARGET.backup_$(date +%Y%m%d_%H%M%S)"
fi
cp -f "$SRC_DIR/GamiT_GlobK_Glorg_FINAL.py" "$TARGET"
chmod +x "$TARGET"
echo "Installed: $TARGET"
echo "Verify with: PYTHONDONTWRITEBYTECODE=1 python3 $TARGET --verify"
echo "Run with:    PYTHONDONTWRITEBYTECODE=1 python3 $TARGET"
