# GitHub Upload Steps

## Option A: Create a new repository

On GitHub, create a new empty repository, for example:

```text
gamit-globk-glorg-automation
```

Then run:

```bash
cd gamit-globk-glorg-automation
git init
git add .
git commit -m "Add GAMIT GLOBK GLORG automation launcher"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/gamit-globk-glorg-automation.git
git push -u origin main
```

## Option B: Upload to existing `datasciencecoursera` repository

Use this only if you really want this project inside that existing repository:

```bash
git clone https://github.com/YOUR_USERNAME/datasciencecoursera.git
cp -r gamit-globk-glorg-automation datasciencecoursera/
cd datasciencecoursera
git add gamit-globk-glorg-automation
git commit -m "Add GAMIT GLOBK GLORG automation launcher"
git push
```

A separate repository name is recommended because this is a geodesy/GNSS project, not a Coursera data-science assignment.
