# Security

Do not commit credentials or private geodetic data.

Never commit:

- `~/.netrc`
- `~/.urs_cookies`
- Earthdata/CDDIS usernames or passwords
- private CORS/RINEX data
- full GAMIT/GLOBK project folders
- large orbit/grid/data products

If credentials were accidentally committed, revoke or rotate them and remove them from Git history.
