# Changelog

## 1.0.0

- GitHub-ready release of the integrated GAMIT/GLOBK/GLORG launcher.
- Includes per-day RINEX-safe GAMIT processing.
- Includes fast `station.info` workflow.
- Includes GLOBK/GLORG dashboard.
- Includes final coordinate extraction.
- Includes requested-epoch coordinate output with safer velocity-source logic.
- Avoids treating local APR/lfile `10.0 10.0 10.0` values as station velocities.
