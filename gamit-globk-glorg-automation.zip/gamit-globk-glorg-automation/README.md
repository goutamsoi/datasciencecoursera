# GAMIT/GLOBK/GLORG Automation Launcher

A single-file Python launcher for semi-automated **GAMIT + GLOBK/GLORG** processing of GNSS/CORS data.

This repository contains a Python wrapper/launcher only. It does **not** include GAMIT/GLOBK, IGS products, Earthdata credentials, RINEX data, or any licensed third-party software/data.

## Main features

- Integrated menu for:
  - GAMIT-only processing
  - GLOBK/GLORG-only processing
  - full GAMIT followed by GLOBK/GLORG
- Per-day RINEX-safe workflow to avoid multi-day contamination.
- Fast `station.info` manager using selected local and IGS/reference sites.
- Support for common local RINEX forms including `.o`, `.o.gz`, `.o.Z`, `.d`, `.d.gz`, `.d.Z`.
- GLOBK/GLORG dashboard with command-file regeneration and patching.
- APR/EQ file selection with frame-aware logic.
- Final coordinate extraction from combined `.org` solution.
- Optional requested-epoch coordinate output.
- Velocity handling options for epoch propagation:
  - measured long-term POS velocity from multi-year GLOBK time series,
  - external station velocity CSV,
  - India plate model based on Jade et al. (2017) for approximate/demo use,
  - APR velocity only when real velocity is present.
- The script avoids treating local `lfile`/APR `10.0 10.0 10.0` entries as velocities.

## Important scientific note on velocity

Epoch propagation requires real station velocity. Coordinates from a short 3–5 day GAMIT/GLOBK run do not provide reliable station velocity.

Use one of these sources for final work:

1. Official station-wise CORS velocity, if available.
2. Measured station velocity from a long-term GAMIT/GLOBK POS time series, preferably two or more years.
3. Plate-model velocity only for approximate/demo propagation.

The India plate model option is not an official station-wise velocity solution.

## Requirements

### Operating system

Recommended: Ubuntu/Linux environment where GAMIT/GLOBK is already installed and working.

### External software

Required commands depend on the selected workflow, but commonly include:

- `python3`
- `sh_gamit`
- `sh_setup`
- `sh_upd_stnfo`
- `sh_glred`
- `globk`
- `glorg`
- `htoglb`
- `crx2rnx`
- `curl`, `gzip`, `gunzip`, `awk`, `sed`

### Python

The script uses Python standard-library modules only. No pip package is required.

Check syntax with:

```bash
python3 -m py_compile GamiT_GlobK_Glorg_FINAL.py
```

## Setup

Clone the repository:

```bash
git clone https://github.com/YOUR_USERNAME/gamit-globk-glorg-automation.git
cd gamit-globk-glorg-automation
chmod +x GamiT_GlobK_Glorg_FINAL.py
```

Source your GAMIT/GLOBK environment before running:

```bash
source ~/.bashrc
# or source the GAMIT/GLOBK setup file used on your system
```

Make sure Earthdata/CDDIS authentication is configured when downloads are needed:

```bash
chmod 600 ~/.netrc
chmod 600 ~/.urs_cookies
```

Do not commit `.netrc`, cookies, RINEX files, h-files, glbf files, logs, or full project folders to GitHub.

## Usage

Run:

```bash
python3 GamiT_GlobK_Glorg_FINAL.py
```

Menu:

```text
1. Run GAMIT only
2. Run GLOBK/GLORG only
3. Run full GAMIT first, then GLOBK/GLORG dashboard
```

For an already processed GAMIT project, choose option `2` and give the project folder, for example:

```text
/home/geodesy/alka2026
```

## Output locations

Typical outputs inside the project folder:

```text
globk_glorg_logs/
gsoln/final_outputs/
gsoln/*.org
gsoln/*.prt
gsoln/*.log
gsoln/pos_*/
```

Important output files may include:

```text
local_final_coordinates.csv
local_coordinates_epoch_YYYYMMDD.csv
station_velocity_from_longterm_pos.csv
station_velocity_template.csv
india_plate_velocity_jade2017_model.csv
pos_statistics.txt
final_processing_report.txt
commands_used.txt
preflight_environment_check.txt
globk_project_health_check.txt
```

## Velocity CSV format

For external station velocity, use:

```csv
station,vx_m_per_yr,vy_m_per_yr,vz_m_per_yr,ve_mm_per_yr,vn_mm_per_yr,vu_mm_per_yr,epoch,source
HYD2_GPS,,,,36.0,35.0,0.0,2020.0,example_only
```

Use either ECEF velocity columns (`vx_m_per_yr`, `vy_m_per_yr`, `vz_m_per_yr`) or ENU velocity columns (`ve_mm_per_yr`, `vn_mm_per_yr`, `vu_mm_per_yr`). Do not fill both unless you know what you are doing.

## Repository hygiene

The `.gitignore` in this repository excludes large and sensitive files, including:

- RINEX files
- GAMIT day folders
- GLOBK binary files
- final processing logs
- Earthdata credential files
- Python cache files

## Citation and acknowledgement

If used for academic or official work, cite GAMIT/GLOBK according to its official guidance and cite any velocity model or station velocity source used for epoch propagation.

For the India plate model option, cite:

Jade, S., Shrungeshwara, T. S., Kumar, K., Choudhury, P., Dumka, R. K., & Bhu, H. (2017). *India plate angular velocity and contemporary deformation rates from continuous GPS measurements from 1996 to 2015*. Scientific Reports, 7, 11439.

## License

The wrapper scripts and repository support files are released under the MIT License. GAMIT/GLOBK itself is not included and remains subject to its own license and distribution terms.
