# Velocity Notes for Requested-Epoch Coordinates

Requested-epoch coordinates require station velocity.

## Why short runs are not enough

A few days of GNSS data can produce a coordinate solution and repeatability statistics, but it cannot produce reliable tectonic velocity. For measured station velocity, use a long time series, preferably two or more years.

## Valid velocity sources

### 1. Measured long-term POS velocity

This is the best scientific option when you have a long GLOBK time series. The launcher can estimate velocity from persistent `.pos` time-series files when there is enough time span.

### 2. External station velocity CSV

Use this when an official or previously estimated station velocity table is available.

### 3. India plate model

This is an approximate/demo option. It uses the India plate angular velocity model from Jade et al. (2017) to compute plate-model velocity from station ECEF coordinates.

### 4. APR velocity

Use only when the APR file contains real velocity values. Local RINEX/lfile entries often have zero velocity and must not be interpreted as measured station velocity.

## About `10.0 10.0 10.0`

Older project APR files may contain local station lines like:

```text
HYD2_GPS X Y Z 10.0 10.0 10.0 epoch
```

Those values are not valid station velocities. The current launcher avoids treating them as velocity and can reset unsafe local `10.0` values.

## External velocity CSV format

```csv
station,vx_m_per_yr,vy_m_per_yr,vz_m_per_yr,ve_mm_per_yr,vn_mm_per_yr,vu_mm_per_yr,epoch,source
HYD2_GPS,,,,36.0,35.0,0.0,2020.0,example_only
```

Use real values, not the example values above.
