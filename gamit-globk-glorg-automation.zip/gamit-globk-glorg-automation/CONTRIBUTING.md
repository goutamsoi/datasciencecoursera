# Contributing

Contributions are welcome for documentation, robustness checks, and small workflow fixes.

Before changing scientific processing logic, test on a known successful GAMIT/GLOBK project and record:

- input project name and date range,
- h-file count,
- selected APR/EQ files,
- stabilization sites,
- daily `.org` count,
- combined `.org` result,
- final coordinate CSV output.

Do not commit proprietary RINEX data, GAMIT/GLOBK distribution files, credentials, `.netrc`, cookies, or project outputs.
